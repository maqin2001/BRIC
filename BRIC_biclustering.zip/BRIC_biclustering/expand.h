#ifndef _EXPAND_H
#define _EXPAND_H

/************************************************************************/

#include "struct.h"

/***********************************************************************/
void read_and_solve_blocks(FILE *fb, const char *fn);
#endif

#ifndef _GET_OPTIONS_H
#define _GET_OPTIONS_H

#include "struct.h"
/*getopt.h is part of the GNU C Library.*/
#include <getopt.h>

/* prototypes */
void get_options(int argc, char *argv[]);

#endif
